
import { useState } from "react";
import "./App.css";

function App() {
  const [tarefas, setTarefas] = useState([]);
  const [novaTarefa, setNovaTarefa] = useState("");

  function adicionarTarefa() {
    if (novaTarefa.trim() === "") return;

    setTarefas([
      ...tarefas,
      {
        id: Date.now(),
        nome: novaTarefa,
        concluida: false,
      },
    ]);

    setNovaTarefa("");
  }

  function concluirTarefa(id) {
    setTarefas(
      tarefas.map((tarefa) =>
        tarefa.id === id
          ? { ...tarefa, concluida: !tarefa.concluida }
          : tarefa
      )
    );
  }

  function excluirTarefa(id) {
    setTarefas(tarefas.filter((tarefa) => tarefa.id !== id));
  }

  return (
    <main className="container">
      <h1>Minha Lista de Tarefas</h1>
      <p>Organize suas atividades do dia!</p>

      <div className="formulario">
        <input
          type="text"
          placeholder="Digite uma tarefa..."
          value={novaTarefa}
          onChange={(e) => setNovaTarefa(e.target.value)}
        />

        <button onClick={adicionarTarefa}>
          Adicionar
        </button>
      </div>

      <ul>
        {tarefas.map((tarefa) => (
          <li key={tarefa.id}>
            <span
              className={tarefa.concluida ? "concluida" : ""}
              onClick={() => concluirTarefa(tarefa.id)}
            >
              {tarefa.nome}
            </span>

            <button onClick={() => excluirTarefa(tarefa.id)}>
              Excluir
            </button>
          </li>
        ))}
      </ul>

      <p>Total de tarefas: {tarefas.length}</p>
    </main>
  );
}

export default App;
